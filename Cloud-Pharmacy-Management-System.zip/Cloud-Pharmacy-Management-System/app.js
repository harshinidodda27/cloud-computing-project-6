const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const app = express();

// Import Routes
const medicineRoutes = require("./routes/medicineRoutes");

// Middleware
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// =============================
// MongoDB Connection (Disabled for now)
// Uncomment this after fixing MongoDB Atlas
// =============================

/*
const MONGO_URI =
"mongodb+srv://YOUR_USERNAME:YOUR_PASSWORD@cluster0.fshquwj.mongodb.net/pharmacyDB?retryWrites=true&w=majority";

mongoose.connect(MONGO_URI)
.then(() => {
    console.log("✅ MongoDB Connected Successfully");
})
.catch((err) => {
    console.log("❌ MongoDB Connection Failed");
    console.log(err.message);
});
*/

// Use Routes
app.use("/", medicineRoutes);

// Start Server
const PORT = 3000;

app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
}); 