const express = require("express");
const router = express.Router();

// Home Page
router.get("/", (req, res) => {
    res.render("index");
});

// Dashboard
router.get("/dashboard", (req, res) => {
    res.render("dashboard");
});

// Medicine Pages
router.get("/add", (req, res) => {
    res.render("addMedicine");
});

router.get("/view", (req, res) => {
    res.render("viewMedicines");
});

router.get("/edit", (req, res) => {
    res.render("editMedicine");
});

// Customer Page
router.get("/customers", (req, res) => {
    res.render("customers");
});

// Billing Page
router.get("/billing", (req, res) => {
    res.render("billing");
});

// About Page
router.get("/about", (req, res) => {
    res.render("about");
});

// Contact Page
router.get("/contact", (req, res) => {
    res.render("contact");
});

module.exports = router; 