const mongoose = require("mongoose");

mongoose.connect(
  "mongodb+srv://hasinikrishna1983668_db_user:Hasini12345@cluster0.fshquwj.mongodb.net/pharmacyDB?retryWrites=true&w=majority"
)
.then(() => {
  console.log("✅ Connected!");
  process.exit(0);
})
.catch((err) => {
  console.error(err);
  process.exit(1);
});